module.exports = {
  serviceId: "ncp:sms:kr:257011693425:dev_conoapp",
  serviceSecret: "9f887285c89c471396c60bfaa53dd27e",
  serviceAccess: "nkSVLr3wy5jnNy3iMFiu",

  serviceSender: "01028301203",
}
