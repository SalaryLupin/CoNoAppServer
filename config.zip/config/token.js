module.exports = {
  jwtSecret: "c@n0app!z34",
  encryptKey: "p@ssword!2E4"
}
